
      </div> <!-- /container -->
      
      <hr />
      <footer>
        <div class="container">
          
          <div class="row">
            <?php dynamic_sidebar('footer-widgets'); ?>
          </div>
          <hr />

          <div class="text-center">
          <p>Sleepytime Distribution | &copy; 2014</p>
          </div>
        </div>

        
      </footer>
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
  <?php wp_footer(); ?>
</html>